from django.apps import AppConfig


class CarmanageConfig(AppConfig):
    name = 'carmanage'
