from django.apps import AppConfig


class DriverConfig(AppConfig):
    name = 'driver'
