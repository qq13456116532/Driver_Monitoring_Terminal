from django.apps import AppConfig


class OperationRecordConfig(AppConfig):
    name = 'operation_record'
    verbose_name = '操作记录'