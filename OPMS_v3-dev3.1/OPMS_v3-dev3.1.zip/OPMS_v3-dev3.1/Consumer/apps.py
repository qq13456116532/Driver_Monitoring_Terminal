from django.apps import AppConfig


class ConsumerConfig(AppConfig):
    name = 'Consumer'
