from django.contrib import admin
from .models import UserOperationRecord

# Register your models here.
admin.site.register(UserOperationRecord)