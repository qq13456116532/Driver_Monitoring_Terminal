from django.apps import AppConfig


class DocumentManagementConfig(AppConfig):
    name = 'document_management'
    verbose_name = '文档管理'