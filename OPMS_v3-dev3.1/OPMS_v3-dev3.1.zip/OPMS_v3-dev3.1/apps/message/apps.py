from django.apps import AppConfig


class MessageConfig(AppConfig):
    name = 'message'
    verbose_name = '用户消息'
