from django.contrib import admin

from carmanage.models import Carmanage

# Register your models here.
admin.site.register(Carmanage)