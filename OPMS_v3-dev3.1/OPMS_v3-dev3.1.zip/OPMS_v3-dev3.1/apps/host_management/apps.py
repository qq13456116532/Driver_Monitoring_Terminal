from django.apps import AppConfig


class HostManagementConfig(AppConfig):
    name = 'host_management'
    verbose_name = '主机管理'
