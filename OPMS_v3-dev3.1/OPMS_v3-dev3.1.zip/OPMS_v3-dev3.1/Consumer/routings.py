# from django.urls import path
#
# from Consumer.MyConsumer import ChatConsumer
#
# app_name = 'Consumer'
#
# websocket_urlpatterns = [
#     # 消息推送socket
#     path('somessws/chat', ChatConsumer.as_asgi())
# ]