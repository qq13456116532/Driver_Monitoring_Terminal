from django.apps import AppConfig


class PlatformManagementConfig(AppConfig):
    name = 'platform_management'
    verbose_name = '平台管理'
