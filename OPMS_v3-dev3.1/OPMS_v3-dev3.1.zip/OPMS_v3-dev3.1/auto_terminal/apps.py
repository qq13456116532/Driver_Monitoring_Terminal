from django.apps import AppConfig


class AutoTerminalConfig(AppConfig):
    name = 'auto_terminal'
