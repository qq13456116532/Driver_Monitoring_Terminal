from django.apps import AppConfig


class OnlineManagementConfig(AppConfig):
    name = 'online_management'
    verbose_name = '线上管理'